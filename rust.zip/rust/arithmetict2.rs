fn main(){
 let n1=3;
 let n2=5;
 let sum = n1+n2 ;
 let sub = n1-n2;
 let mul = n1*n2;
 let div = n1/n2;
 
println!("The sum of {} and {} is {}", n1, n2, sum);
println!("The subtraction of {} and {} is {}", n1, n2, sub);
println!("The product of {} and {} is {}", n1, n2,mul);
println!("The division of {} and {} is {}", n1, n2, div);
}
