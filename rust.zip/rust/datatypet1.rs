fn main() {
   
    let integer_variable= 42;
    let float_variable= 3.14;
    let boolean_variable= true;
    let char_variable= 'R';

    println!("Integer value: {}", integer_variable);
    println!("Floating-point value: {}", float_variable);
    println!("Boolean value: {}", boolean_variable);
    println!("Character value: {}", char_variable);
}

