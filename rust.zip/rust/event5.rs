fn main() {
    for number in 1..=20 {
        if number % 2 == 0 {
            println!("{}", number);
        }
    }
}

