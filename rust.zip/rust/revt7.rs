fn main() {
    for number in (1..=10).rev() {
        println!("{}", number);
    }
}

